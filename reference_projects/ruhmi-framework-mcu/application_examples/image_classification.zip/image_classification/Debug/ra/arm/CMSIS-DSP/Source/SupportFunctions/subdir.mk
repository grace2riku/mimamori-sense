################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bitonic_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bubble_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_float.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_float.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_heap_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_insertion_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_init_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_float.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_float.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q7.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_f64.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_float.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q15.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q31.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_quick_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_selection_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_init_f32.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f16.c \
../ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f32.c 

CREF += \
vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_mobilenet_v1.cref 

C_DEPS += \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bitonic_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bubble_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_float.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_float.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_heap_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_insertion_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_init_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_float.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_float.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q7.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_f64.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_float.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q15.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q31.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_quick_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_selection_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_init_f32.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f16.d \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f32.d 

OBJS += \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_barycenter_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bitonic_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_bubble_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_copy_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_float.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f16_to_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_float.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_f64_to_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_fill_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_float_to_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_heap_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_insertion_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_merge_sort_init_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_float.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q15_to_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_float.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q31_to_q7.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_f64.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_float.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q15.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_q7_to_q31.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_quick_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_selection_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_sort_init_f32.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f16.o \
./ra/arm/CMSIS-DSP/Source/SupportFunctions/arm_weighted_average_f32.o 

MAP += \
vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_mobilenet_v1.map 


# Each subdirectory must supply rules for building sources it contributes
ra/arm/CMSIS-DSP/Source/SupportFunctions/%.o: ../ra/arm/CMSIS-DSP/Source/SupportFunctions/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -O2 -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -w -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src" -I"." -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\fsp\\inc" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\fsp\\inc\\api" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\fsp\\inc\\instances" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\fsp\\src\\rm_freertos_port" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\aws\\FreeRTOS\\FreeRTOS\\Source\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS_6\\CMSIS\\Core\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra_gen" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra_cfg\\fsp_cfg\\bsp" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra_cfg\\fsp_cfg" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra_cfg\\aws" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\ai_application" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\ai_application\\common" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\camera_layer" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\display_layer" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\fsp_custom" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\time_counter" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\console_output" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\external_memory" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\tes\\dave2d\\inc" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-View\\EventRecorder\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-View\\EventRecorder\\Config" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ruy" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\gemmlowp" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\tflite-micro" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-software\\lib\\crc\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-software\\lib\\ethosu_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-software\\lib\\layer_by_layer_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-software\\lib\\arm_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-software\\lib\\ethosu_monitor\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\ethos-u-core-driver\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\fsp\\src\\rm_ethosu" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-DSP\\PrivateInclude" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-DSP\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\npu\\flatbuffers\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-NN\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\ra\\arm\\CMSIS-NN" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\image_classification.zip_expanded\\image_classification\\src\\ai_application\\image_classification" -D_RENESAS_RA_ -D_RA_CORE=CPU0 -DETHOSU55 -DETHOSU_ARCH=u55 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"


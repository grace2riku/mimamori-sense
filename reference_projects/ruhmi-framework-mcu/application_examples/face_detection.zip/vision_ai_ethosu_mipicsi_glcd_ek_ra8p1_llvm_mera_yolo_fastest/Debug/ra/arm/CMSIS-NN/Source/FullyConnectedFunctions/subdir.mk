################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s16.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s16.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_per_channel_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s16.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s4.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_wrapper_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8.c \
../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8_s64.c 

CREF += \
vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest.cref 

C_DEPS += \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s16.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s16.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_per_channel_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s16.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s4.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_wrapper_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8.d \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8_s64.d 

OBJS += \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s16.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_batch_matmul_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s16.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_per_channel_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s16.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s4.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_wrapper_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8.o \
./ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_vector_sum_s8_s64.o 

MAP += \
vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest.map 


# Each subdirectory must supply rules for building sources it contributes
ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/%.o: ../ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -O2 -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -w -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src" -I"." -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\fsp\\inc" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\fsp\\inc\\api" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\fsp\\inc\\instances" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\fsp\\src\\rm_freertos_port" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\aws\\FreeRTOS\\FreeRTOS\\Source\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS_6\\CMSIS\\Core\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra_gen" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra_cfg\\fsp_cfg\\bsp" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra_cfg\\fsp_cfg" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra_cfg\\aws" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\ai_application" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\ai_application\\common" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\ai_application\\face_detection" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\camera_layer" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\display_layer" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\fsp_custom" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\time_counter" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\console_output" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\src\\external_memory" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\tes\\dave2d\\inc" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-View\\EventRecorder\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-View\\EventRecorder\\Config" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ruy" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\gemmlowp" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\tflite-micro" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-software\\lib\\crc\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-software\\lib\\ethosu_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-software\\lib\\layer_by_layer_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-software\\lib\\arm_profiler\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-software\\lib\\ethosu_monitor\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\ethos-u-core-driver\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\fsp\\src\\rm_ethosu" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-DSP\\PrivateInclude" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-DSP\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\npu\\flatbuffers\\include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-NN\\Include" -I"C:\\Users\\a5033228\\e2_studio\\workspace_20251201\\vision_ai_ethosu_mipicsi_glcd_ek_ra8p1_llvm_mera_yolo_fastest\\ra\\arm\\CMSIS-NN" -D_RENESAS_RA_ -D_RA_CORE=CPU0 -DETHOSU55 -DETHOSU_ARCH=u55 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"


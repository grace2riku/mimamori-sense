# trace-r1 静的検証記録

実機未確認。ソース・配布ELFの逆アセンブルを照合した記録。

- CPU0全1,595オブジェクトを診断コピーから再コンパイルしリンク成功。再利用したCPU0オブジェクトなし。
- 入力来歴は../build-provenance.json。変更はinstrumentation.diffの8ユーザーソースとboot_trace.c/hのみ。通常ソースのgit diffは空。
- 生成／ライブラリを含む変更対象外の入力3,722ファイルについてコピーと通常ツリーのハッシュ一致を確認。
- コンパイルには既存ヘッダ由来のCMSIS符号変換・r_typedefsのtypedef再宣言等の警告がある。新規計測処理のコンパイルエラーなし。個別ログは診断コピーDebug/*.o.log、リンクログは../link.log。
- CPU1はmain-wait-r2保存物。MOT SHA-256一致。MOT/ELFロード内容・entry・チェックサム一致、CPU0/CPU1アドレス重複0。数値のマスタはbuild-verification.json。
- s_boot_traceは0x2210BEA0、サイズ0x3C8=968バイト、内部RAM BSS。固定26スロット。POST_Cは内部BSS初期化後。外部SDRAM初期化では消えない配置。
- 全26点のソース上の記録呼出しと公開5関数の定義／参照を照合し、最終リンク成功。LTOにより一部関数はインライン化される。

## 実命令

以下はRTC_TRACE_CPU0-disassembly.txtのアドレス。ツールチェーン表示の<unknown>（一部MVE命令）から意味を推測せず、対象の通常命令とソースを照合した。

- SystemInit 0x0203E5E0。内部ランタイム初期化0x0203EDB2→SystemCoreClockUpdate 0x0203EDB6→RCR4ストア0x0203EDBA。
- POST_CのDWT進行プローブとメタ情報保存の後、0x0203EFAAでr0=200、0x0203EFACでr1=1000、0x0203EFB0でR_BSP_SoftwareDelay。既存のIOPORT/SDRAM処理はその後に続く。200msは要求値であり実時間は未測定。
- RTC初期化はntshell_task（0x02012010）にインライン展開。記録呼出しは0x02012180以降。分岐結果ごとに0x0201224Cまたは0x020122B6からboot_trace_branchへ進む。ClockSourceSetのリセット／待ちは非成立経路に残る。OPEN/GETの戻り値処理と同期条件を差分で維持確認。
- 最初の最終領域flush: lvgl_port_mtk3_flush_cb 0x02006C00。BEGIN記録0x02006C10、BufferChangeの再試行後END記録0x02006C3C。初期BufferChangeとは別スロット。
- flush_wait 0x02006C8C。BEGIN記録0x02006C98、tk_wai_semの復帰値をENDへ渡す0x02006CC0。LVGLライブラリは変更なし。
- backlightコールバック0x02004038内、PinWrite後の記録0x0200405A。FLUSH_FINISHはVsync待ち完了と同一視しない。
- boot_trace_mark 0x02041CDAは既記録なら即復帰。タスク排他の下でtrace_locked 0x02041D64を呼ぶ。trace_lockedはtk_get_otm→DWT/世代/結果の保存→最後に通番publish（0x02041DBA）。
- AIのDWTリセットはAIタスクにインライン展開。成功経路0x0200B944でディスパッチ禁止状態をpublishし、0x0200B950でCYCCNT=0、0x0200B95Eで世代更新、0x0200B98Aでディスパッチ再開。異常経路はfaultを設定し解析器がDWTを無効化する。
- usrcmd_boottrace 0x02041E78。固定968バイトsnapshotをタスク排他内でコピーし、UART出力前に解除。自身のstackフレームは0x4DC+push 36=1280バイト。NT-Shell stack設定4096バイト（usermain.c:195）。呼出し連鎖全体の実機stack高水位は未測定。
- CYCCNT/CTRL書込みをsrc/ra/mtk3_bsp2で検索。AI resetは世代管理済み、cameraは無効時だけresetするがPOST_Cで先に有効化。Dave2Dはenableのみ。EventRecorderのenableは最終symbolsに関数なし。実験中にデバッガからカウンタを変更する操作は対象外。

## 解析検証と限界

- log-parser-tests.txt: 12件成功。合成ログで未記録、同一tick、世代跨ぎ、周回不明、modulo周回、APIエラー、不正FW、通番異常、切れたログ、進行プローブ不良、OS/DWT不整合を検証。
- 初期化／表示の成功と実画面の正常を区別する。PC接続の最大2起動は取得試運転で白率評価ではない。
- 無限待ち・シェル停止時の救済取得、キャッシュ整合を保証したデバッガ読出し、ACでのログ取得はこの版の範囲外。
- 再リンクと固定RAM記録には観測影響がある。白が消えても修正成功とは扱わない。
